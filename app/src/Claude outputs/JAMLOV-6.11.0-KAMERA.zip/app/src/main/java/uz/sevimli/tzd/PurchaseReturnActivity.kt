package uz.sevimli.tzd

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import org.json.JSONArray
import org.json.JSONObject
import uz.sevimli.tzd.databinding.ActivityPurchaseReturnBinding
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

class PurchaseReturnActivity : AppCompatActivity() {

    private lateinit var b: ActivityPurchaseReturnBinding

    private val fmt = NumberFormat.getInstance(Locale("uz"))
    private val items = mutableListOf<SupplyItem>()
    /** Ro'yxat adapteri — qatorlarni qayta ishlatadi (RecyclerView). */
    private val rowAdapter = DocRowAdapter { pos ->
        items.getOrNull(pos)?.let { editItem(it) }
    }

    private var cpId: Int = -1
    private var cpName: String = ""
    private val clientUuid = UUID.randomUUID().toString()

    // Skaner (miqdor oynasi ochiq turganda) uchun holat
    private var qtyDialog: android.app.AlertDialog? = null
    private var qtyConfirmWith: ((Double) -> Unit)? = null
    private var qtyPrefill: Double = 0.0
    private val scanBuf = StringBuilder()
    private var lastScanKey = 0L

    private val pickCp = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == RESULT_OK && res.data != null) {
            cpId = res.data!!.getIntExtra("cp_id", -1)
            cpName = res.data!!.getStringExtra("cp_name") ?: ""
            b.headerCp.text = cpName
        } else if (cpId < 0) {
            finish() // kontragent tanlanmasa, chiqamiz
        }
    }

    private val pickProduct = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == RESULT_OK && res.data != null) {
            val json = productFromIntent(res.data!!)
            askQuantity(json, json.optString("barcode"))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPurchaseReturnBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = rowAdapter
        b.list.setHasFixedSize(true)

        b.btnBack.setOnClickListener { confirmExit() }
        b.btnFinish.setOnClickListener { finishDocument() }
        // Pastdagi katta tugma — AYNAN o'sha amal. TSD ekrani baland,
        // yuqoridagi kichik belgiga bir qo'lda yetish qiyin edi.
        b.btnFinishBig.setOnClickListener { finishDocument() }
        b.btnManualAdd.setOnClickListener {
            pickProduct.launch(Intent(this, ProductSearchActivity::class.java)
                .putExtra("price_mode", "buy"))
        }
        // Skan uch kanaldan qabul qilinadi: Enter, Enter'siz (jimlik) va
        // qurilma skaner signali. Tafsilot — ScanInput.kt
        ScanInput.bind(this, b.scanInput) { code -> onScan(code) }

        // Avval kontragent tanlash
        pickCp.launch(Intent(this, CounterpartyActivity::class.java))
    }

    private fun onScan(code: String) {
        b.loading.visibility = View.VISIBLE
        thread {
            val result = Api.get(this, "product", mapOf("barcode" to code))
            // Internet bo'lmasa — mahalliy (offline) bazadan qidiramiz
            val json: org.json.JSONObject? = when (result) {
                is ApiResult.Success -> result.json
                is ApiResult.Error -> if (result.offline) OfflineLookup.lookup(this, code) else null
            }
            val serverErr = (result as? ApiResult.Error)?.takeIf { !it.offline }?.message
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                b.loading.visibility = View.GONE
                when {
                    serverErr != null -> {
                        ScanFeedback.fail(this)
                        Toast.makeText(this, serverErr, Toast.LENGTH_SHORT).show()
                    }
                    json == null || !json.optBoolean("found", false) -> {
                        ScanFeedback.fail(this)
                        Toast.makeText(this, getString(R.string.product_not_found), Toast.LENGTH_SHORT).show()
                    }
                    else -> {
                        ScanFeedback.ok(this)
                        askQuantity(json, code)
                    }
                }
            }
        }
    }

    private fun askQuantity(product: JSONObject, code: String) {
        val name = product.optString("name")
        // Возврат поставщику uchun KIRIM (закупочная) narxi.
        //
        // ILGARI bu yerda `product.optLong("price", 0)` zaxira turardi va
        // kirim narxi kelmasa SOTUV narxi olinardi. Natijada "Kirim" yozuvi
        // ostida chakana narx ko'rinar, bundan ham yomoni - o'sha narx
        // MoySklad возврат hujjatiga yozilardi.
        //
        // Endi zaxira yo'l YO'Q: narx topilmasa 0 bo'ladi va ekranda ochiq
        // ogohlantirish chiqadi. Xato jimgina yashirinib qolmaydi.
        val price = product.optLong("buy_price", 0)
        val pmid = product.optString("moysklad_id",
            product.optString("code")) // backend product_moysklad_id qaytarmasa fallback
        // Diqqat: barcode bo'sh bo'lishi mumkin (qo'lda qo'shilgan mahsulot),
        // shuning uchun bo'sh kodni solishtirmaymiz — aks holda turli mahsulotlar
        // bir-biriga aralashib ketishi mumkin edi.
        // Qatorlarni ISHONCHLI kalit — mahsulot ID si bo'yicha birlashtiramiz (barcode zaxira).
        // Ilgari NOM bo'yicha ham birlashtirilardi — bir xil nomli turli mahsulotlar
        // aralashib, miqdor buzilardi.
        val existing = items.find {
            (pmid.isNotBlank() && it.productMoyskladId == pmid) ||
                    (code.isNotBlank() && it.barcode == code)
        }
        val was = existing?.quantity ?: 0.0

        val view = LayoutInflater.from(this).inflate(R.layout.dialog_quantity, null)
        val qName = view.findViewById<TextView>(R.id.qName)
        val qPrice = view.findViewById<TextView>(R.id.qPrice)
        val qPackInfo = view.findViewById<TextView>(R.id.qPackInfo)
        val qWas = view.findViewById<TextView>(R.id.qWas)
        val qWill = view.findViewById<TextView>(R.id.qWill)
        val qInput = view.findViewById<EditText>(R.id.qInput)
        val btnMinus = view.findViewById<TextView>(R.id.btnMinus)
        val btnPlus = view.findViewById<TextView>(R.id.btnPlus)
        val btnOk = view.findViewById<View>(R.id.btnOk)

        qName.text = name
        val storeQty = product.optDouble("store_qty", -1.0)
        qPrice.text = when {
            price > 0 && storeQty >= 0 -> getString(
                R.string.buy_price_qty_fmt, fmt.format(price), trimNum(storeQty))
            price > 0 -> getString(R.string.buy_price_fmt, fmt.format(price))
            storeQty >= 0 -> getString(
                R.string.buy_price_missing_qty_fmt, trimNum(storeQty))
            else -> getString(R.string.buy_price_missing)
        }
        if (price <= 0) qPrice.setTextColor(getColor(R.color.warning))
        qWas.text = getString(R.string.was_fmt, trimNum(was))

        // Tarozi shtrixi — og'irlik (kg), yoki Upakovka (blok) — ichidagi dona: avto to'ldiramiz
        val packQty = product.optDouble("pack_qty", 0.0)
        val isPack = product.optBoolean("is_pack", false) && packQty > 0
        val packUom = product.optString("uom", "").let { if (it.isBlank()) "" else " $it" }
        val scaleWeight = product.optDouble("scale_weight", 0.0)
        when {
            product.optBoolean("scale", false) && scaleWeight > 0 -> {
                qPackInfo.visibility = View.VISIBLE
                qPackInfo.text = getString(R.string.scale_fmt, trimNum(scaleWeight))
                qInput.setText(trimNum(scaleWeight))
            }
            isPack -> {
                qPackInfo.visibility = View.VISIBLE
                qInput.setText("1")
            }
            // QR dagi GTIN-14 BLOK ekanini ko'rsatyapti, lekin ichida nechta
            // dona ekani MoySklad'da ro'yxatdan o'tmagan — xodim o'zi kiritadi.
            product.optBoolean("pack_unknown", false) -> {
                qPackInfo.visibility = View.VISIBLE
                qPackInfo.text = getString(R.string.blok_enter_qty_u)
                qInput.setText("")
            }
            else -> {
                qPackInfo.visibility = View.GONE
                qInput.setText("1")
            }
        }

        fun typedQty(): Double = qInput.text.toString().toDoubleOrNull() ?: 0.0
        // UPAKOVKA: kiritilgan raqam — upakovka SONI. Hujjatga esa ichidagi
        // jami miqdor yoziladi: 1 upakovka x 3 kg = 3 kg.
        fun currentQty(): Double {
            val typed = typedQty()
            if (!isPack) return typed
            val total = round3(typed * packQty)
            qPackInfo.text =
                getString(R.string.pack_calc_fmt_u, trimNum(typed), trimNum(packQty), trimNum(total), packUom)
            return total
        }
        fun updateWill() { qWill.text = getString(R.string.will_fmt, trimNum(was + currentQty())) }
        updateWill()
        qInput.setOnFocusChangeListener { _, _ -> updateWill() }
        qInput.setSelection(qInput.text.length)

        btnMinus.setOnClickListener {
            val v = (typedQty() - 1).coerceAtLeast(0.0); qInput.setText(trimNum(v)); updateWill()
        }
        btnPlus.setOnClickListener {
            qInput.setText(trimNum(typedQty() + 1)); updateWill()
        }

        val dialog = AlertDialog.Builder(this).setView(view).create()
        // Będet doim yangilansin
        qInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { updateWill() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val confirmWith: (Double) -> Unit = { addQty ->
            if (addQty > 0) {
                if (existing != null) existing.quantity = round3(existing.quantity + addQty)
                else items.add(SupplyItem(pmid, code, name, price, addQty))
                renderList()
            }
            dialog.dismiss()
        }
        btnOk.setOnClickListener { confirmWith(currentQty()) }

        // Skaner: oyna ochiq turganda keyingi mahsulot skanlansa — joriyni standart
        // miqdor bilan tasdiqlab, yangisiga o'tamiz (raqamlar miqdorga tushmaydi).
        qtyPrefill = currentQty()
        qtyConfirmWith = confirmWith
        qtyDialog = dialog
        dialog.setOnDismissListener { qtyDialog = null; qtyConfirmWith = null }
        dialog.show()
    }

    private fun renderList() {
        b.emptyHint.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        b.totalCount.text = getString(R.string.total_items_fmt, items.size)
        val kirimSum = items.sumOf { it.price * it.quantity }
        b.totalSum.text = getString(R.string.sum_fmt, fmt.format(kirimSum.toLong()))
        // Ro'yxat adapterga beriladi — RecyclerView faqat ko'rinib
        // turgan qatorlarni chizadi (ilgari hammasi qayta yasalardi).
        rowAdapter.submit(items.map { item ->
            DocRowAdapter.Row(item.name, trimNum(item.quantity))
        })
    }

    private fun editItem(item: SupplyItem) {
        // qayta miqdor kiritish (o'chirish uchun 0)
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(trimNum(item.quantity))
        }
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setMessage(getString(R.string.new_qty_hint))
            .setView(input)
            .setPositiveButton(getString(R.string.save_kt)) { _, _ ->
                val v = input.text.toString().toDoubleOrNull() ?: item.quantity
                if (v <= 0) items.remove(item) else item.quantity = v
                renderList()
            }
            .setNegativeButton(getString(R.string.cancel_short), null)
            .show()
    }

    private fun finishDocument() {
        if (items.isEmpty()) {
            Toast.makeText(this, getString(R.string.doc_empty), Toast.LENGTH_SHORT).show(); return
        }
        if (cpId < 0) {
            Toast.makeText(this, getString(R.string.cp_not_set), Toast.LENGTH_SHORT).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.purchase_return_kt))
            .setMessage(getString(R.string.confirm_write_fmt, items.size, trimNum(items.sumOf { it.quantity })))
            .setPositiveButton(getString(R.string.finish_ru)) { _, _ -> sendDocument() }
            .setNegativeButton(getString(R.string.cancel_short), null)
            .show()
    }

    /** Yuborish qulfi — ikki marta bosilsa ikkinchi so'rov ketmaydi. */
    private val busy = Busy()

    private fun sendDocument() {
        if (!busy.start(b.btnFinish, b.btnFinishBig)) return    // allaqachon yuborilyapti
        b.loading.visibility = View.VISIBLE
        val lines = JSONArray()
        for (item in items) {
            lines.put(JSONObject().apply {
                put("product_moysklad_id", item.productMoyskladId)
                put("barcode", item.barcode)
                put("name", item.name)
                put("quantity", item.quantity)
                put("price", item.price)
            })
        }
        val orgId = Config.orgId(this)
        val body = JSONObject().apply {
            put("client_uuid", clientUuid)
            put("organization_id", orgId)
            put("counterparty_id", cpId)
            put("lines", lines)
        }
        thread {
            val result = Api.post(this, "purchase-return", body)
            runOnUiThread {
                busy.stop(b.btnFinish, b.btnFinishBig)
                if (isFinishing || isDestroyed) return@runOnUiThread
                b.loading.visibility = View.GONE
                when (result) {
                    is ApiResult.Success -> {
                        val name = result.json.optString("moysklad_name", getString(R.string.purchase_return))
                        AlertDialog.Builder(this)
                            .setTitle(getString(R.string.sent_ok))
                            .setMessage("MoySklad: $name")
                            .setPositiveButton(getString(R.string.ok)) { _, _ -> finish() }
                            .setCancelable(false)
                            .show()
                    }
                    is ApiResult.Error -> {
                        if (result.offline) {
                            // Internet yo'q — hujjatni navbatga saqlaymiz, keyin o'zi yuboriladi.
                            OfflineQueue.enqueue(this, "purchase-return", getString(R.string.purchase_return), body)
                            AlertDialog.Builder(this)
                                .setTitle(getString(R.string.saved_pending))
                                .setMessage(getString(R.string.offline_saved))
                                .setPositiveButton(getString(R.string.ok)) { _, _ -> finish() }
                                .setCancelable(false)
                                .show()
                        } else {
                            AlertDialog.Builder(this)
                                .setTitle(getString(R.string.not_sent))
                                .setMessage(result.message)
                                .setPositiveButton(getString(R.string.ok), null)
                                .show()
                        }
                    }
                }
            }
        }
    }

    /** Apparat "orqaga" tugmasi ham ishni jimgina yo'qotib yubormasin.
     *  targetSdk 34 da bu chaqiruv hali ishlaydi (faqat eskirgan deb belgilangan). */
    @Suppress("DEPRECATION")
    override fun onBackPressed() { confirmExit() }

    private fun confirmExit() {
        if (items.isEmpty()) { finish(); return }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.exit))
            .setMessage(getString(R.string.doc_unfinished_exit))
            .setPositiveButton(getString(R.string.exit)) { _, _ -> finish() }
            .setNegativeButton(getString(R.string.stay2), null)
            .show()
    }

    /** Miqdorni 3 xonagacha yaxlitlaydi (0.1+0.2 kabi "shovqin"ni yo'qotadi). */
    private fun round3(d: Double): Double = Math.round(d * 1000.0) / 1000.0

    private fun trimNum(d: Double): String {
        val r = round3(d)
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
    }


    /** ProductSearchActivity'dan qaytgan tanlovni product_lookup javobi kabi JSON'ga aylantiradi. */
    private fun productFromIntent(data: Intent): JSONObject = JSONObject().apply {
        put("found", true)
        put("name", data.getStringExtra("p_name") ?: "")
        put("barcode", data.getStringExtra("p_barcode") ?: "")
        put("price", data.getLongExtra("p_price", 0))
        put("buy_price", data.getLongExtra("p_buy_price", 0))
        put("moysklad_id", data.getStringExtra("p_moysklad_id") ?: "")
        put("uom", data.getStringExtra("p_uom") ?: "")
        put("store_qty", data.getDoubleExtra("p_store_qty", 0.0))
        val pq = data.getDoubleExtra("p_pack_qty", 0.0)
        if (pq > 0) { put("pack_qty", pq); put("is_pack", true) }
    }

    override fun onResume() {
        super.onResume()
        b.scanInput.requestFocus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) b.scanInput.requestFocus()
    }

    /** Miqdor oynasi ochiq turganda kelgan SKAN (tez ketma-ketlik + Enter) ni ushlaymiz. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (qtyDialog?.isShowing == true && event.action == KeyEvent.ACTION_DOWN) {
            val now = System.currentTimeMillis()
            if (now - lastScanKey > 150) scanBuf.setLength(0)
            lastScanKey = now
            val kc = event.keyCode
            if (kc == KeyEvent.KEYCODE_ENTER || kc == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                val code = scanBuf.toString().trim()
                scanBuf.setLength(0)
                if (code.length >= 6) {                    // barcode — yangi mahsulot
                    qtyConfirmWith?.invoke(qtyPrefill)     // joriyni standart miqdor bilan tasdiqlaymiz
                    onScan(code)
                    return true
                }
            } else {
                val ch = event.unicodeChar
                if (ch != 0) scanBuf.append(ch.toChar())
            }
        }
        return super.dispatchKeyEvent(event)
    }
}
